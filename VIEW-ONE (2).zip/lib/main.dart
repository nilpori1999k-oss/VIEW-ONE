<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIEW1ON - Video Sharing & Social Media</title>
    <link href="https://googleapis.com" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f9f9f9;
            color: #0f0f0f;
        }
        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: #ffffff;
            border-bottom: 1px solid #e5e5e5;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 22px;
            font-weight: 800;
            color: #ff0000;
            letter-spacing: -0.5px;
        }
        .logo span {
            color: #0f0f0f;
        }
        .search-bar {
            display: flex;
            width: 45%;
            max-width: 550px;
        }
        .search-bar input {
            width: 100%;
            padding: 8px 15px;
            border: 1px solid #ccc;
            border-radius: 20px 0 0 20px;
            outline: none;
            font-size: 14px;
        }
        .search-bar button {
            padding: 8px 18px;
            border: 1px solid #ccc;
            border-left: none;
            background: #f8f8f8;
            border-radius: 0 20px 20px 0;
            cursor: pointer;
        }
        .header-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .btn-upload {
            display: flex;
            align-items: center;
            gap: 5px;
            background: #f2f2f2;
            border: none;
            padding: 8px 14px;
            border-radius: 20px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-upload:hover {
            background: #e5e5e5;
        }
        .profile-pic {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: #ff0000;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            cursor: pointer;
        }

        /* Layout */
        .container {
            display: flex;
        }
        /* Sidebar */
        .sidebar {
            width: 220px;
            background: #ffffff;
            height: calc(100vh - 57px);
            padding: 15px 10px;
            border-right: 1px solid #e5e5e5;
            position: sticky;
            top: 57px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 15px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 5px;
        }
        .nav-item:hover, .nav-item.active {
            background: #f2f2f2;
            font-weight: 600;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 20px;
        }
        .categories {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            overflow-x: auto;
        }
        .cat-chip {
            padding: 6px 14px;
            background: #f2f2f2;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            white-space: nowrap;
        }
        .cat-chip.active {
            background: #0f0f0f;
            color: #ffffff;
        }

        /* Video Grid */
        .video-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .video-card {
            cursor: pointer;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            transition: transform 0.2s;
        }
        .video-card:hover {
            transform: translateY(-2px);
        }
        .thumbnail {
            width: 100%;
            height: 165px;
            background: #ddd;
            position: relative;
            object-fit: cover;
        }
        .duration {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background: rgba(0, 0, 0, 0.8);
            color: #fff;
            padding: 2px 6px;
            font-size: 11px;
            border-radius: 4px;
        }
        .video-info {
            display: flex;
            gap: 12px;
            padding: 12px;
        }
        .channel-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #333;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
            flex-shrink: 0;
        }
        .video-details h4 {
            font-size: 15px;
            margin-bottom: 4px;
            line-height: 1.3;
        }
        .video-details p {
            font-size: 13px;
            color: #606060;
        }

        /* Shorts Section */
        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin: 30px 0 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .shorts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 15px;
        }
        .short-card {
            height: 310px;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
            background: #222;
            cursor: pointer;
        }
        .short-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.85;
        }
        .short-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 12px;
            background: linear-gradient(transparent, rgba(0,0,0,0.85));
            color: #fff;
        }
        .short-overlay h5 {
            font-size: 14px;
            margin-bottom: 4px;
        }
        .short-overlay span {
            font-size: 12px;
            color: #ddd;
        }

        /* Modal for Video Player & Upload */
        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.75);
            justify-content: center;
            align-items: center;
            z-index: 200;
        }
        .modal-content {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            width: 90%;
            max-width: 700px;
            position: relative;
        }
        .close-btn {
            position: absolute;
            top: 12px;
            right: 15px;
            font-size: 22px;
            cursor: pointer;
            font-weight: bold;
        }
        .modal-content input, .modal-content select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        .btn-submit {
            background: #ff0000;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .search-bar { width: 55%; }
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="logo">
            <span class="material-icons" style="color:#ff0000; font-size:28px;">play_circle_filled</span>
            VIEW<span>1ON</span>
        </div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="ভিডিও, শর্টস বা চ্যানেল খুঁজুন..." onkeyup="filterVideos()">
            <button><span class="material-icons" style="font-size:18px;">search</span></button>
        </div>
        <div class="header-icons">
            <button class="btn-upload" onclick="openUploadModal()">
                <span class="material-icons" style="font-size:18px;">video_call</span> তৈরি করুন
            </button>
            <span class="material-icons" style="cursor:pointer;">notifications</span>
            <div class="profile-pic" title="Farid (App Owner)">F</div>
        </div>
    </header>

    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="nav-item active"><span class="material-icons">home</span> হোম</div>
            <div class="nav-item"><span class="material-icons">bolt</span> শর্টস (Shorts)</div>
            <div class="nav-item"><span class="material-icons">subscriptions</span> সাবস্ক্রিপশন</div>
            <div class="nav-item"><span class="material-icons">live_tv</span> লাইভ স্ট্রিম</div>
            <hr style="margin: 10px 0; border: 0; border-top: 1px solid #eee;">
            <div class="nav-item"><span class="material-icons">video_library</span> আপনার চ্যানেল</div>
            <div class="nav-item"><span class="material-icons">history</span> ওয়াচ হিস্ট্রি</div>
            <div class="nav-item"><span class="material-icons">monetization_on</span> মনিটাইজেশন</div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Categories -->
