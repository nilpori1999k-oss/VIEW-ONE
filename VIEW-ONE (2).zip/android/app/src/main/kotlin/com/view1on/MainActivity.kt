package com.view1on

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
